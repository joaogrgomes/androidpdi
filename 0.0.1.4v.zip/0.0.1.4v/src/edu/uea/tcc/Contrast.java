package edu.uea.tcc;


import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Contrast {



	//http://www.raditha.com/java/image/rgb.php
	//http://simple2.googlecode.com/svn/trunk/SImPLe/src/simple/modules/propriedades/histograma/Histograma.java

	


		public static void main(String[] args) throws IOException {
			// Lendo Imagem
			BufferedImage imagem = ImageIO.read(new File("lena.bmp"));
			
			
			int largura = imagem.getWidth();
			int altura = imagem.getHeight();
			int nbands = imagem.getSampleModel().getNumBands();
			
			int posicao = 0;
			
			double[] histograma = new double[256]; // Niveis de cinza 2^8
			double[] pk = new double[256];  //vetor de probabilidades
			double[] sk = new double[256];  //vetor de distribuicao acumulada
			double[] nk = new double[256];  //vetor de niveis de saida
			double[] niveis = new double[256]; //vetor de niveis padrao para 256 niveis de cores
			
			// acesso aos pixels
			Raster inputRaster = imagem.getRaster();
			int[] pixel = new int[largura * altura * nbands];
			int n = pixel.length;
			inputRaster.getPixels(0, 0, largura, altura, pixel);
			WritableRaster outputRaster = imagem.getRaster();
			

			System.out.println("Largura: " + largura + " Altura: " + altura 	+ " Componentes de Cor: " + nbands);

			//Histograma - numero de pixels que apresentam determinado nivel de cinza h[rk]
			//h[rk] = nk  
			//rk nivel de cinza
			//nk numero de pixels da imagem com nivel cinza	
			for (int banda = 0; banda < nbands; banda++) {
				for (int y = 0; y < altura; y++) {
					for (int x = 0; x < largura; x++) {
						histograma[inputRaster.getSample(x, y, banda)]++;
					
					}
				}
			}
			
			
			//Histograma normalizado - probabilidade de cada nivel de cinza
			//pr(rk) = nk/n				
			for (int x = 0; x < histograma.length; x++) {
				//System.out.println(histograma[x] );
				pk[x] =  (histograma[x])/ n ; 
				
		   }
			System.out.println();
			
			//Sk = somatorio de pk
			sk[0] = pk[0];
			for (int x = 1; x < histograma.length; x++) {
			    sk[x] = pk[x] + sk[x - 1] ;
			    //System.out.println(sk[x] );
						
		   }
			
			//vetor com todos os niveis padrao dos tons de cinza
			
			for (int x = 0; x < niveis.length; x++) {
				double nivel = x;
				niveis[x] =  nivel / 255; 
				//System.out.println(niveis[x] );
		   }
			
			//Equalizacao de histograma
			
			for(int x = 0; x < sk.length; x++){
				
				for (int y = 0; y < niveis.length; y++){
					if ( sk[x] <= niveis[y] ){
						continue;
					}
					if( y == 0 ){
						y++;
					}
					posicao = y;
				}
				
				nk[x] = posicao;
			}
			
			//Escrever nova imagem
			
			for (int banda = 0; banda < nbands; banda++) {
				for (int y = 0; y < altura; y++) {
					for (int x = 0; x < largura; x++) {
						int px = inputRaster.getSample(x, y, banda); 
						outputRaster.setSample(x, y, banda,nk[px]);  
					}
				}
			}
			
			
			// Escrever na imagem
			ImageIO.write(imagem, "bmp", (new File("saidaEqualizada.bmp")));
			System.out.println("Histograma de Imagem Equalizado");
		
	

		
		}	
}
