package edu.uea.tcc;

import java.io.File;
import java.util.Date;

import ngvl.android.gallery.R;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class Principal extends Activity {
	private Bitmap fotoTirada;
	private ImageView imageView1;
	private File caminhoFoto;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		//imageView1 = (ImageView) findViewById(R.id.imageView1);
		
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		apagaTemp();
	}

	public void galleryButtonClick(View v) {
		apagaTemp();

		Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
		intent.setType("image/*");
		startActivityForResult(intent, 0);
	}

	public void tirarFotoClick(View v) {
		apagaTemp();

		String nomeFoto = "foto"+ DateFormat.format("yyyy-MM-dd_hhmmss", new Date()).toString();

		caminhoFoto = new File(Environment.getExternalStorageDirectory(), nomeFoto);

		Intent it = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		it.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(caminhoFoto));
		startActivityForResult(it, 1);
	}

	private void apagaTemp() {
		if (caminhoFoto != null && caminhoFoto.exists()) {
			caminhoFoto.delete();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (resultCode == RESULT_OK) {
			switch (requestCode) {
			case 0:

				Uri selectedImage = data.getData();
				String[] filePathColumn = { MediaStore.Images.Media.DATA };

				Cursor cursor = getContentResolver().query(selectedImage,
						filePathColumn, null, null, null);
				cursor.moveToFirst();

				int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
				String filePath = cursor.getString(columnIndex); 
				cursor.close();

				Bitmap yourSelectedImage = BitmapFactory.decodeFile(filePath);

				imageView1.setImageBitmap(yourSelectedImage);

				break;

			case 1:
				fotoTirada = BitmapFactory.decodeFile(caminhoFoto
						.getAbsolutePath());
				imageView1.setImageBitmap(fotoTirada);
				break;
			}
		}
	}
}