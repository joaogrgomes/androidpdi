/** Automatically generated file. DO NOT MODIFY */
package br.edu.tcc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}